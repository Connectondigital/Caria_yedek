const brandConfig = {
    APP_NAME: "Caria Estates",
    ADMIN_NAME: "Caria CRM",
    LOGO_TEXT_MAIN: "CARIA",
    LOGO_TEXT_SUB: "CRM",
    FOOTER_TEXT: "© 2026 Caria Estates. All Rights Reserved.",
    VERSION: "1.1.0",
};

export default brandConfig;
