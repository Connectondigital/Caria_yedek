# Changelog

## [2.0.0] 2025-13-01

### Upgraded to React 19 ⚡️

## [1.1.0] 2024-07-26

🚀 New features:

- React tables updated to Tanstack V8

## [1.0.1] 2023-03-07

🐛 Bugs solved:

- Bug with charts being uneven fixed

## [1.0.0] 2023-02-27

### Original Release

- Added Tailwind CSS as base framework
